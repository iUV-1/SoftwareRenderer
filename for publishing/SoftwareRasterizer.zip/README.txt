**USAGE**
In terminal (Windows 11) or command prompt (Windows <10), navigate to this folder and run the following command: 
./SoftwareRenderer.exe <.obj model> <.tga texture>

Sample 3d model and texture has been included in the obj folder
Follow the instruction on screen.
